<?php defined('BASEPATH') OR exit('No direct script access allowed');
define('BACKUP_DIR', './uploads/invoice' ) ;

class Booking_management extends CI_Controller 
{
	
	function __construct()
    {
        parent::__construct();
        $this->load->model('General_data');
	    $this->load->model('Sms_email');
	}
	
	 
	
	
	public function from_city_list(){
		$city_list = $this->db->get('city_detail')->result();
		
		/*$data=array();
		$i=1;
		$total=0;
		foreach($city_list as $row){
			$data[$i]=$row;
			
			$total=$i;
			
			$i++;
		}
		
		$response=array('success'=>'success' ,'message'=>'Successfully Found From City List','total'=>$total, 'from_city_list'=>$data);*/
		
		$response=array('from_city_list'=>$city_list);
		
		echo json_encode($response);
	}
	
	public function payment_type_list(){
		$payment_type = $this->db->get('payment_type')->result();
		
		/*$data=array();
		$i=1;
		$total=0;
		foreach($payment_type as $row){
			$data[$i]=$row;
			
			$total=$i;
			
			$i++;
		}
		
		$response=array('success'=>'success' ,'message'=>'Successfully Found Payment Type List','total'=>$total, 'payment_type_list'=>$data);*/
		
		$response=array('payment_type_list'=>$payment_type);
		
		echo json_encode($response);
	}
	
	
	public function booking_list(){
	
		date_default_timezone_set('Asia/Kolkata');
		
		if(isset($_POST['id'])){
		
			$data=array();
			$i=1;
			$total=0;
			
			$this->db->select('booking_list.*,package_type.package_sub_type,package_type.package_type,city_detail.c_name,payment_type.payment_name');
			$this->db->from('booking_list');
			$this->db->join('package_type','package_type.id=booking_list.b_type');
			$this->db->join('city_detail','city_detail.id=booking_list.b_from_city');
			$this->db->join('payment_type','payment_type.id=booking_list.b_payment_type');
			$this->db->where('booking_list.b_p_id',$_POST['id']);
			$this->db->order_by('booking_list.id','DESC');
			$booking__list = $this->db->get()->result();
			foreach($booking__list as $b){
			
				$data[$i]=$b;
				$data[$i]->b_route = $b->c_name;
				if(($b->b_type == '3') || ($b->b_type == '4'))
				{
				    $data[$i]->b_route = $b->c_name." - ".$b->b_to_city;
				}
				
				if($b->b_type == '1' || $b->b_type == '2')
				{
				    $to_city = $this->db->get_where('city_detail',array('id'=>$b->b_to_city))->row()->c_name;
					$data[$i]->b_route = $b->c_name." - ".$to_city;
				}
				
				if($b->b_invoice_id!=0)
				{
					$invoice = $this->db->get_where('invoice',array('id'=>$b->b_invoice_id))->row();
					$data[$i]->invoice_detail = $invoice;
				}
				else
				{
					$data[$i]->invoice_detail = "";
					
				}
				
				
				$total=$i;
				$i++;
				
			}
			
			$response=array('success'=>'success' ,'message'=>'Successfully Get Booking List','total'=>$total, 'booking_list'=>$data);
			
		}else{
			$response=array('success'=>'error','message'=>'Parameter Missing');
		}
		echo json_encode($response);
	}
	
	public function booking_details(){
		date_default_timezone_set('Asia/Kolkata');
		
		if(isset($_POST['booking_id'])){
		
			
			
			$this->db->select('booking_list.*,package_type.package_sub_type,package_type.package_type,city_detail.c_name,payment_type.payment_name');
			$this->db->from('booking_list');
			$this->db->join('package_type','package_type.id=booking_list.b_type');
			$this->db->join('city_detail','city_detail.id=booking_list.b_from_city');
			$this->db->join('payment_type','payment_type.id=booking_list.b_payment_type');
			$this->db->where('booking_list.id',$_POST['booking_id']);
			$b = $this->db->get()->row();
			
			$data=$b;
			$data->b_route = $b->c_name;
			if(($b->b_type == '3') || ($b->b_type == '4'))
			{
			    $data->b_route = $b->c_name." - ".$b->b_to_city;
			}
				
			if($b->b_type == '1' || $b->b_type == '2')
			{
			    $to_city = $this->db->get_where('city_detail',array('id'=>$b->b_to_city))->row()->c_name;
				$data->b_route = $b->c_name." - ".$to_city;
			}
				
			if($b->b_invoice_id!=0)
			{
				$invoice = $this->db->get_where('invoice',array('id'=>$b->b_invoice_id))->row();
				$data->invoice_detail = $invoice;
			}
			else
			{
				$data->invoice_detail = "";
				
			}
				
			$response=array('success'=>'success' ,'message'=>'Successfully Get Booking Details', 'booking_details'=>$data);
		}else{
			$response=array('success'=>'error','message'=>'Parameter Missing');
		}
		echo json_encode($response);
	}
	
	public function update_booking()
	{
		date_default_timezone_set('Asia/Kolkata');
		$data=$this->input->post(null,true);
		
		if(!isset($data['b_to_date']))
		{
			$data['b_to_date'] = "0000-00-00";
		}
		else
		{
		    	$data['b_to_date'] = date('Y-m-d',strtotime($data['b_to_date']));
		}

		//echo $data['date']."<br>";
	
		$array= array(
			'b_p_name' =>$data['b_p_name'],
			'b_p_contact'=>$data['b_p_contact'],
			'b_self_travel_status'=>$data['b_self_travel_status'],
			'b_pickup_point'=>$data['b_pickup_point'],
			'b_drop_point' =>$data['b_drop_point'],
			'b_from_date' =>date('Y-m-d',strtotime($data['b_from_date'])),
			'b_from_time' =>date('H:i:s',strtotime($data['b_from_time'])),
			'b_to_date' =>	$data['b_to_date'] ,
			'b_updated_date_time'=>date('Y-m-d H:i:s')
		);
		
		//print_r($array);
		
		$this->db->where('id',$data['booking_id']);
		$this->db->update('booking_list',$array);
		
		$response['success']="success";
		
		echo json_encode($response);
		
	}
	
	public function cancel_booking()
	{
		date_default_timezone_set('Asia/Kolkata');
		
		$this->load->model('General_data');
		
		if(isset($_POST['cancel_note'])){
			$cancel_note= $_POST['cancel_note'];
		}else{
			$cancel_note= '';
		}
		
		
		$cancel_booking = array(	'b_status'=>0,
									'b_cancel_type'=>1,
									'b_cancel_date_time'=>date('Y-m-d H:i:s'),
									'b_cancel_note'=>$cancel_note
									);
									
									
		$this->General_data->update_data('booking_list',$this->input->post('booking_id'),$cancel_booking);
		
		$this->db->select('booking_list.*,package_type.package_type,package_type.package_sub_type,city_detail.c_name,payment_type.payment_name');
		$this->db->from('booking_list');
		$this->db->join('package_type','package_type.id=booking_list.b_type');
		$this->db->join('city_detail','city_detail.id=booking_list.b_from_city');
		$this->db->join('payment_type','payment_type.id=booking_list.b_payment_type');
		$this->db->where('booking_list.id',$this->input->post('booking_id'));
		$booking_details = $this->db->get()->row();
			
			
		date_default_timezone_set('Asia/Kolkata');
		
		$pickup_dateTime = date($booking_details->b_from_date.' '.$booking_details->b_from_time);
   		
		$date1 = new DateTime($pickup_dateTime);
		$date2 = new DateTime();
 	
		$diff = $date2->diff($date1);
 
		
		$total_hours_difference = $diff->h + ($diff->d * 24); 
		if($total_hours_difference <=24)
		{
			$refund_time = 'Within 48 Hours';
			$advance_return = 0;
		}
		else
		{
			$refund_time = 'Before 48 Hours';
			$advance_return = $booking_details->b_advance;
		}
		
		
		$message = "Dear ".$booking_details->b_p_name.", We regret to inform the cancellation of your booking ".$booking_details->b_id.". We'd have loved to serve you. Call Rashmi Cabs on +91 9974234111 for any help.";
		
		
		$mobile_no=$booking_details->b_p_contact;
		
		
		$this->Sms_email->send_sms($mobile_no,$message);
		
		$passenger_details=$this->db->get_where('passenger_list',array('id'=>$booking_details->b_p_id))->row();
		
		if($booking_details->b_self_travel_status != 1)
		{
			$mobile_no_2=$passenger_details->p_contact;
			
			$message_2 = "Dear ".$passenger_details->p_full_name.", We regret to inform the cancellation of your booking ".$booking_details->b_id.". We'd have loved to serve you. Call Rashmi Cabs on +91 9974234111 for any help.";
		
		
			
			$this->Sms_email->send_sms($mobile_no_2,$message_2);
		}
		
		//send email
		$to      = $passenger_details->p_email_id;
		$subject = 'Rashmi Cabs';
		
		$data['booking_details']=$booking_details;
		$data['passenger_details']=$passenger_details;
		$data['message']='Thank you for booking with us Rashmi Cabs your Ref #'.$booking_details->b_id.' was cancelled '.$refund_time.', hence your refund amount is Rs.'.$advance_return.' and will be processed in 7 Business Days..';
		
 		$message_mail = $this->load->view('mail_booking_cancel',$data,true);
		
		$this->Sms_email->send_email($to, $subject, $message_mail);
		
		
		//sms to agent
		
		if(!empty($booking_details->b_agent_id)){
		
			$agent_details=$this->db->get_where('agent_detail',array('id'=>$booking_details->b_agent_id))->row();
		
			$agent_mobile_no = $agent_details->a_contact_no1;
			
			$agent_message = 'Dear '.$agent_details->a_full_name.',Cancellation alert = '.$booking_details->b_id.' duty with '.$booking_details->b_p_name.'  '.$booking_details->b_p_contact.' = '.date('jS M Y',strtotime($booking_details->b_from_date)).' has been cancelled plz note. Team Rashmi Cabs.';
			
			$this->Sms_email->send_sms($agent_mobile_no,$agent_message);	
		
		
		}
		
		$response['success']="success";
		
		echo json_encode($response);
			
	}
	
	public function InvoiceMail()
	{
		//$id = 52;
		   
		//echo $id; exit;		   
	
		$id=$_POST['invoice_id'];
		
		   
		$data['invoice'] = $this->db->get_where('invoice',array('id'=>$id))->row();
		   
		$rent_card_id = $this->db->get_where('booking_list',array('b_invoice_id'=>$id))->row()->b_rent_card_id;
			
		$data['rent_card'] = $this->db->get_where('rent_cards',array('id'=>$rent_card_id))->row();
			
		$booking_details = $this->db->get_where('booking_list',array('b_invoice_id'=>$id))->row();
		   
		if($booking_details->b_ac_non_ac==1)
		{
			$data['ac_non_ac'] =  ' AC';
		}
		else
		{
			$data['ac_non_ac'] =  ' NON AC';
		}
		
		$data['booking_details'] = $this->db->get_where('booking_list',array('b_invoice_id'=>$id))->row();
		$data['passenger_details']=$this->db->get_where('passenger_list',array('id'=>$data['booking_details']->b_p_id))->row();
			
		
		if($data['invoice']->type=="LOCAL" || $data['invoice']->sub_type=="ONEWAY") {
			$invoice_template=$this->load->view('invoice_view_local_pdf',$data,true);
		}else if($data['invoice']->sub_type=="ONEWAY OFFER" || $data['invoice']->sub_type=="ROUNDTRIP" || $data['invoice']->sub_type=="MULTICITY") {
			$invoice_template=$this->load->view('invoice_view_pdf',$data,true);
		}
		
		//echo $invoice_template;
			
			
		//generate pdf
		if (!file_exists(BACKUP_DIR)) mkdir(BACKUP_DIR , 0755) ;
        if (!is_writable(BACKUP_DIR)) chmod(BACKUP_DIR , 0755) ;
			
		$pdfFilePath = BACKUP_DIR."/invoice.pdf";
	 
		//load mPDF library
		$this->load->library('m_pdf');
	 
		//generate the PDF from the given html
		$this->m_pdf->pdf->WriteHTML($invoice_template);
	 
		//download it.
		$this->m_pdf->pdf->Output($pdfFilePath, "F");  
			
					
		$data['message']='Thank you for booking with us Rashmi Cabs your Ref #'.$data['booking_details']->b_id.' Hope you had a wonderful trip. <br> Please Check Attachment Invoice File';
					
		$body = $this->load->view('mail_booking_trip_complete',$data,true);
		//echo $message_mail;exit;
			
			
		$filename= "invoice.pdf";
		$my_path = BACKUP_DIR . '/';
				
		$file = $my_path.$filename;
		$file_size = filesize($file);
		$handle = fopen($file, "r");
		$content = fread($handle, $file_size);
		fclose($handle);
	
		$content = chunk_split(base64_encode($content));
		$uid = md5(uniqid(time()));
		$name = basename($file);
		$eol = PHP_EOL;
		   
			   
		   
		$to      = $data['passenger_details']->p_email_id;
		$subject = 'Rashmi Cabs';
				
		$from_name = "Rashmi Cabs";
		$from_mail = 'rashmicabs@gmail.com';
		$replyto = "rashmicabs@gmail.com";
			
		// Basic headers
		$header = "From: ".$from_name." <".$from_mail.">".$eol;
		$header .= "Reply-To: ".$replyto.$eol;
		$header .= "MIME-Version: 1.0\r\n";
		$header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"";
			
		// Put everything else in $message
		//$message = "--".$uid.$eol;
		//$message .= "Content-Transfer-Encoding: 7bit".$eol.$eol;
		$message .= "--".$uid.$eol;
		$message .= "Content-Type: text/html; charset=ISO-8859-1".$eol;
		$message .= "Content-Transfer-Encoding: 8bit".$eol.$eol;
		$message .= $body.$eol;
		$message .= "--".$uid.$eol;
		$message .= "Content-Type: application/octet-stream; name=\"".$filename."\"".$eol;
		$message .= "Content-Transfer-Encoding: base64".$eol;
		$message .= "Content-Disposition: attachment".$eol.$eol;
		$message .= $content.$eol;
		$message .= "--".$uid."--";
							
		mail($to, $subject, $message, $header);
		
		$response['success']="success";
		
		echo json_encode($response);
		
	}
	
	public function slider_list(){
		$slider = $this->db->get('slider')->result();
		
		$data=array();
		$i=1;
		$total=0;
		foreach($slider as $row){
			$data[$i]['id']=$row->id;
			$data[$i]['image_name']=$row->s_cover_image;
			$data[$i]['image_path']=base_url()."uploads/slider/cover_image/".$row->s_cover_image;
			
			$total=$i;
			
			$i++;
		}
		
		$response=array('success'=>'success' ,'message'=>'Successfully Found Slider List','total'=>$total, 'slider_list'=>$data);
		
		echo json_encode($response);
	}
	
}












